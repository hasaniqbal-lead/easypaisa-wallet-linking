import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { WalletLinksService } from './wallet-links.service';
import { WalletLink } from './entities/wallet-link.entity';
import { EasypaisaModule } from '../easypaisa/easypaisa.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([WalletLink]),
    EasypaisaModule,
  ],
  providers: [WalletLinksService],
  exports: [WalletLinksService],
})
export class WalletLinksModule {}
