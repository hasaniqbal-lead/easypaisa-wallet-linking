import { IsString, IsNotEmpty, Length } from 'class-validator';

export class InitiateLinkDto {
  @IsString()
  @IsNotEmpty()
  walletLinkId: string;

  @IsString()
  @IsNotEmpty()
  orderId: string;

  @IsString()
  @IsNotEmpty()
  @Length(4, 6, { message: 'OTP must be between 4 and 6 characters' })
  otp: string;
}
