import { Injectable, Logger, HttpException, HttpStatus } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { ConfigService } from '@nestjs/config';
import { firstValueFrom } from 'rxjs';
import { SignatureService } from './signature.service';
import {
  GenerateOtpRequest,
  GenerateOtpResponse,
} from './dto/generate-otp.dto';
import {
  InitiateLinkRequest,
  InitiateLinkResponse,
} from './dto/initiate-link.dto';
import {
  PinlessPaymentRequest,
  PinlessPaymentResponse,
} from './dto/pinless-payment.dto';
import {
  DeactivateLinkRequest,
  DeactivateLinkResponse,
} from './dto/deactivate-link.dto';
import {
  EASYPAISA_ERROR_CODES,
  getErrorMessage,
  getErrorHttpStatus,
  isRetryableError,
} from '../common/constants/error-codes';

@Injectable()
export class EasypaisaService {
  private readonly logger = new Logger(EasypaisaService.name);
  private readonly baseUrl = 'https://easypay.easypaisa.com.pk/easypay-service/rest/pinless/v1.0';

  constructor(
    private readonly httpService: HttpService,
    private readonly signatureService: SignatureService,
    private readonly configService: ConfigService,
  ) {}

  /**
   * Generate OTP for wallet linking
   */
  async generateOtp(
    mobileAccountNo: string,
    orderId: string,
    emailAddress?: string,
  ): Promise<GenerateOtpResponse> {
    // IMPORTANT: Only send storeId and mobileAccountNo in the request
    // Do NOT include username, password, orderId, or emailAddress
    const request = {
      storeId: this.configService.get<string>('easypaisa.storeId')!,
      mobileAccountNo,
    };

    const signature = this.signatureService.generateSignature(request);

    const payload = {
      request,
      signature,
    };

    try {
      this.logger.log(`Generating OTP for order: ${orderId}, mobile: ${mobileAccountNo}`);

      const response = await firstValueFrom(
        this.httpService.post(`${this.baseUrl}/generate-otp`, payload, {
          headers: {
            'Content-Type': 'application/json',
          },
          timeout: this.configService.get<number>('easypaisa.timeoutMs')!,
        }),
      );

      this.logger.log(`OTP generated successfully for order ${orderId}`);
      return this.handleResponse(response.data);
    } catch (error) {
      this.logger.error(`OTP generation failed for order ${orderId}: ${error.message}`);
      throw this.handleError(error);
    }
  }

  /**
   * Initiate wallet link transaction (verify OTP and link wallet)
   */
  async initiateLinkTransaction(
    mobileAccountNo: string,
    orderId: string,
    otp: string,
    transactionAmount: number,
    emailAddress?: string,
  ): Promise<InitiateLinkResponse> {
    const request: InitiateLinkRequest = {
      username: this.configService.get<string>('easypaisa.username')!,
      password: this.configService.get<string>('easypaisa.password')!,
      storeId: this.configService.get<string>('easypaisa.storeId')!,
      orderId,
      transactionAmount: transactionAmount.toFixed(2),
      transactionType: 'MA',
      mobileAccountNo,
      emailAddress: emailAddress || '',
      otp,
    };

    const signature = this.signatureService.generateSignature(request);

    const payload = {
      request,
      signature,
    };

    try {
      this.logger.log(`Initiating link transaction for order: ${orderId}`);

      const response = await firstValueFrom(
        this.httpService.post(`${this.baseUrl}/initiate-link-transaction`, payload, {
          headers: {
            'Content-Type': 'application/json',
          },
          timeout: this.configService.get<number>('easypaisa.timeoutMs')!,
        }),
      );

      this.logger.log(`Wallet linked successfully for order ${orderId}`);
      return this.handleResponse(response.data);
    } catch (error) {
      this.logger.error(`Link transaction failed for order ${orderId}: ${error.message}`);
      throw this.handleError(error);
    }
  }

  /**
   * Initiate pinless transaction (charge wallet without PIN)
   */
  async initiatePinlessTransaction(
    tokenNumber: string,
    mobileAccountNo: string,
    orderId: string,
    transactionAmount: number,
    emailAddress?: string,
  ): Promise<PinlessPaymentResponse> {
    const request: PinlessPaymentRequest = {
      username: this.configService.get<string>('easypaisa.username')!,
      password: this.configService.get<string>('easypaisa.password')!,
      storeId: this.configService.get<string>('easypaisa.storeId')!,
      orderId,
      transactionAmount: transactionAmount.toFixed(2),
      transactionType: 'MA',
      mobileAccountNo,
      emailAddress: emailAddress || '',
      tokenNumber,
    };

    const signature = this.signatureService.generateSignature(request);

    const payload = {
      request,
      signature,
    };

    try {
      this.logger.log(`Initiating pinless transaction for order: ${orderId}, amount: ${transactionAmount}`);

      const response = await firstValueFrom(
        this.httpService.post(`${this.baseUrl}/initiate-pinless-transaction`, payload, {
          headers: {
            'Content-Type': 'application/json',
          },
          timeout: this.configService.get<number>('easypaisa.timeoutMs')! + 15000, // Longer timeout for payment
        }),
      );

      this.logger.log(`Pinless transaction completed successfully for order ${orderId}`);
      return this.handleResponse(response.data);
    } catch (error) {
      this.logger.error(`Pinless transaction failed for order ${orderId}: ${error.message}`);
      throw this.handleError(error);
    }
  }

  /**
   * Deactivate wallet link
   */
  async deactivateLink(
    tokenNumber: string,
    mobileAccountNo: string,
  ): Promise<DeactivateLinkResponse> {
    const orderId = `DELINK-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

    const request: DeactivateLinkRequest = {
      username: this.configService.get<string>('easypaisa.username')!,
      password: this.configService.get<string>('easypaisa.password')!,
      storeId: this.configService.get<string>('easypaisa.storeId')!,
      orderId,
      mobileAccountNo,
      tokenNumber,
    };

    const signature = this.signatureService.generateSignature(request);

    const payload = {
      request,
      signature,
    };

    try {
      this.logger.log(`Deactivating link for token: ${tokenNumber}`);

      const response = await firstValueFrom(
        this.httpService.post(`${this.baseUrl}/deactivate-link`, payload, {
          headers: {
            'Content-Type': 'application/json',
          },
          timeout: this.configService.get<number>('easypaisa.timeoutMs')!,
        }),
      );

      this.logger.log(`Link deactivated successfully for token ${tokenNumber}`);
      return this.handleResponse(response.data);
    } catch (error) {
      this.logger.error(`Link deactivation failed for token ${tokenNumber}: ${error.message}`);
      throw this.handleError(error);
    }
  }

  /**
   * Handle Easypaisa API response
   */
  private handleResponse(data: any): any {
    const response = data.response || data;
    const responseCode = response.responseCode;

    if (responseCode !== '0000') {
      const errorInfo = EASYPAISA_ERROR_CODES[responseCode];
      const httpStatus = errorInfo?.httpStatus || HttpStatus.INTERNAL_SERVER_ERROR;
      const message = errorInfo?.message || 'Unknown error from Easypaisa';

      this.logger.warn(`Easypaisa returned error code ${responseCode}: ${message}`);

      throw new HttpException(
        {
          statusCode: httpStatus,
          message,
          easypaisaCode: responseCode,
          easypaisaMessage: response.responseMessage,
          retryable: isRetryableError(responseCode),
        },
        httpStatus,
      );
    }

    return response;
  }

  /**
   * Handle HTTP errors
   */
  private handleError(error: any): HttpException {
    if (error instanceof HttpException) {
      return error;
    }

    // Network errors
    if (error.code === 'ECONNREFUSED' || error.code === 'ETIMEDOUT' || error.code === 'ENOTFOUND') {
      return new HttpException(
        {
          statusCode: HttpStatus.SERVICE_UNAVAILABLE,
          message: 'Easypaisa service unavailable',
          error: error.message,
          retryable: true,
        },
        HttpStatus.SERVICE_UNAVAILABLE,
      );
    }

    // Timeout errors
    if (error.code === 'ECONNABORTED' || error.message?.includes('timeout')) {
      return new HttpException(
        {
          statusCode: HttpStatus.GATEWAY_TIMEOUT,
          message: 'Request to Easypaisa timed out',
          error: error.message,
          retryable: true,
        },
        HttpStatus.GATEWAY_TIMEOUT,
      );
    }

    // Generic error
    return new HttpException(
      {
        statusCode: HttpStatus.INTERNAL_SERVER_ERROR,
        message: 'Internal server error',
        error: error.message,
        retryable: false,
      },
      HttpStatus.INTERNAL_SERVER_ERROR,
    );
  }
}
