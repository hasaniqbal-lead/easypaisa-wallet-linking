import { Module } from '@nestjs/common';
import { MerchantApiController } from './merchant-api.controller';
import { WalletLinksModule } from '../wallet-links/wallet-links.module';
import { TransactionsModule } from '../transactions/transactions.module';
import { MerchantsModule } from '../merchants/merchants.module';
import { AuditModule } from '../audit/audit.module';

@Module({
  imports: [
    WalletLinksModule,
    TransactionsModule,
    MerchantsModule,
    AuditModule,
  ],
  controllers: [MerchantApiController],
})
export class MerchantApiModule {}
