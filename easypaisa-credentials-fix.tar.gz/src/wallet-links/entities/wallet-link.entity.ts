import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  OneToMany,
  Index,
} from 'typeorm';
import { Merchant } from '../../merchants/entities/merchant.entity';
import { Transaction } from '../../transactions/entities/transaction.entity';

export enum WalletLinkStatus {
  PENDING = 'pending',
  OTP_GENERATED = 'otp_generated',
  ACTIVE = 'active',
  DEACTIVATED = 'deactivated',
  EXPIRED = 'expired',
  FAILED = 'failed',
}

@Entity('wallet_links')
@Index(['merchantId', 'mobileNumber'])
@Index(['token'])
export class WalletLink {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'uuid', name: 'merchant_id' })
  merchantId: string;

  @ManyToOne(() => Merchant, (merchant) => merchant.walletLinks)
  @JoinColumn({ name: 'merchant_id' })
  merchant: Merchant;

  @Column({ name: 'mobile_number' })
  mobileNumber: string;

  @Column({ nullable: true })
  token: string;

  @Column({
    type: 'enum',
    enum: WalletLinkStatus,
    default: WalletLinkStatus.PENDING,
  })
  status: WalletLinkStatus;

  @Column({ nullable: true, name: 'otp_reference' })
  otpReference: string;

  @Column({ type: 'timestamp', nullable: true, name: 'otp_expires_at' })
  otpExpiresAt: Date;

  @Column({ nullable: true, name: 'easypaisa_order_id' })
  easypaisaOrderId: string;

  @Column({ type: 'jsonb', nullable: true, name: 'easypaisa_response' })
  easypaisaResponse: Record<string, any>;

  @Column({ type: 'timestamp', nullable: true, name: 'linked_at' })
  linkedAt: Date;

  @Column({ type: 'timestamp', nullable: true, name: 'expires_at' })
  expiresAt: Date;

  @Column({ type: 'timestamp', nullable: true, name: 'deactivated_at' })
  deactivatedAt: Date;

  @Column({ type: 'text', nullable: true, name: 'deactivation_reason' })
  deactivationReason: string;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;

  @OneToMany(() => Transaction, (txn) => txn.walletLink)
  transactions: Transaction[];
}
